#1. What is a block-level element? What are examples? What are they used for?
Block-level elements are structural elements like lists, divs, paragraphs and headings. They are used to give structure to an html document.
#2. When do you use these elements? When might you use a div versus a section element?
[Chart of elements](http://reference.sitepoint.com/html/block-level)
Headers, Footers, and Bodies are examples of sections, while divs are containers that you would use within a section. So sections are larger blocks while divs are smaller and can be used for specific functions.
#3. What is an inline element?
Inline elements typically do not begin with a new line. Elements like attributes, emphasis, or links are inline elements.
#4. Do inline elements usually nest inside block-level elements?
Yes. Inline elements usually nest inside block-level elements.